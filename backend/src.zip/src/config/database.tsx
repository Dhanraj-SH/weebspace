import mongoose from "mongoose";
import { env } from "./env.js";

export const connection = async (): Promise<void> => {
    try {
        await mongoose.connect(env.MONGODB_URI);

        console.log("MongoDB connected successfully");
    } catch (error) {
        console.error("MongoDB connection failed", error);
        process.exit(1);
    }
};
